# MyCloud 5GB — Flutter starter

This starter includes:
- Email/password registration and login
- Private per-user file paths in Firebase Storage
- Upload, list, download-ready storage paths, delete
- A 5 GB usage meter based on Firestore file metadata
- Android and iOS support through Flutter

## Important production warning

The included 5 GB check is a **client-side starter check**, not a secure aggregate quota. A modified client could bypass it, and concurrent uploads could exceed the limit. The Firebase Storage rules enforce ownership and a 100 MB per-file cap, but do not enforce the total 5 GB per-user quota.

Before public launch, implement a trusted backend upload-reservation flow (for example Cloud Functions/Cloud Run) that reserves bytes atomically, validates quota, and issues short-lived upload authorization. Also add server-side metadata verification, cleanup for failed uploads, App Check, rate limits, monitoring, backups, and billing alerts. Do not advertise the quota as securely enforced until that backend is deployed and tested.

## Requirements

1. Install Flutter SDK and Android Studio. For iOS builds, use a Mac with Xcode.
2. Create a Firebase project at https://console.firebase.google.com/
3. Enable **Authentication > Email/Password**.
4. Create a **Cloud Firestore** database.
5. Enable **Cloud Storage**.
6. Install FlutterFire CLI:
   ```bash
   dart pub global activate flutterfire_cli
   ```
7. In this project folder, run:
   ```bash
   flutter pub get
   flutterfire configure
   ```
   Select your Firebase project and Android/iOS platforms. This generates `lib/firebase_options.dart` and platform configuration.
8. Replace the `Firebase.initializeApp()` call in `lib/main.dart` with:
   ```dart
   await Firebase.initializeApp(
     options: DefaultFirebaseOptions.currentPlatform,
   );
   ```
   Add this import:
   ```dart
   import 'firebase_options.dart';
   ```
9. Publish the rules in `firebase/storage.rules` and `firebase/firestore.rules` using Firebase Console or Firebase CLI.
10. Run on Android:
    ```bash
    flutter run
    ```
11. Build Android APK:
    ```bash
    flutter build apk --release
    ```
    APK output: `build/app/outputs/flutter-apk/app-release.apk`
12. Build iOS (on macOS with Xcode):
    ```bash
    flutter build ios --release
    ```

## Notes

- The app currently uses email/password authentication.
- File picker loads file bytes into memory; the 100 MB per-file starter limit helps avoid excessive memory use.
- The app stores file metadata in `users/{uid}/files/{fileId}` and file bytes in `users/{uid}/{fileId}-{filename}`.
- The current starter shows storage usage from metadata and does not yet implement restore/trash, sharing, password reset, or a production quota backend.
- Firebase Storage and Firestore are paid services beyond their applicable free quotas. Check current Firebase pricing for your region and expected usage before launch.
