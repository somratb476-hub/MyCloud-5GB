import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:file_picker/file_picker.dart';
import 'package:intl/intl.dart';

const int quotaBytes = 5 * 1024 * 1024 * 1024;
const int maxFileBytes = 100 * 1024 * 1024; // Starter safety limit: 100 MB/file.

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(); // Configure with FlutterFire CLI first.
  runApp(const MyCloudApp());
}

class MyCloudApp extends StatelessWidget {
  const MyCloudApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MyCloud 5GB',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorSchemeSeed: const Color(0xFF2878D0), useMaterial3: true),
      home: const AuthGate(),
    );
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        return snapshot.data == null ? const LoginPage() : const HomePage();
      },
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool createAccount = false;
  bool busy = false;
  String? error;

  Future<void> submit() async {
    setState(() { busy = true; error = null; });
    try {
      if (createAccount) {
        await FirebaseAuth.instance.createUserWithEmailAndPassword(
          email: email.text.trim(), password: password.text,
        );
      } else {
        await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: email.text.trim(), password: password.text,
        );
      }
    } on FirebaseAuthException catch (e) {
      setState(() => error = e.message ?? e.code);
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  void dispose() {
    email.dispose();
    password.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 420),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.cloud_upload, size: 64, color: Color(0xFF2878D0)),
              const SizedBox(height: 8),
              const Text('MyCloud 5GB', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
              const SizedBox(height: 24),
              TextField(controller: email, keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(labelText: 'Email', border: OutlineInputBorder())),
              const SizedBox(height: 12),
              TextField(controller: password, obscureText: true,
                decoration: const InputDecoration(labelText: 'Password', border: OutlineInputBorder())),
              if (error != null) Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(error!, style: const TextStyle(color: Colors.red)),
              ),
              const SizedBox(height: 16),
              FilledButton(onPressed: busy ? null : submit,
                child: Text(busy ? 'Please wait...' : createAccount ? 'Create account' : 'Login')),
              TextButton(onPressed: () => setState(() => createAccount = !createAccount),
                child: Text(createAccount ? 'Already registered? Login' : 'New here? Create account')),
            ]),
          ),
        ),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  String sizeText(int bytes) {
    if (bytes >= 1024 * 1024 * 1024) return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(2)} GB';
    if (bytes >= 1024 * 1024) return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    if (bytes >= 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    return '$bytes B';
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser!;
    final files = FirebaseFirestore.instance.collection('users').doc(user.uid).collection('files');
    return Scaffold(
      appBar: AppBar(title: const Text('MyCloud 5GB'), actions: [
        IconButton(tooltip: 'Logout', onPressed: () => FirebaseAuth.instance.signOut(),
          icon: const Icon(Icons.logout)),
      ]),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => uploadFile(context), icon: const Icon(Icons.upload), label: const Text('Upload'),
      ),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: files.orderBy('createdAt', descending: true).snapshots(),
        builder: (context, snapshot) {
          if (snapshot.hasError) return Center(child: Text('Error: ${snapshot.error}'));
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final docs = snapshot.data!.docs;
          final used = docs.fold<int>(0, (sum, d) => sum + ((d.data()['size'] ?? 0) as num).toInt());
          final ratio = (used / quotaBytes).clamp(0.0, 1.0);
          return Column(children: [
            Card(
              margin: const EdgeInsets.all(16),
              child: Padding(padding: const EdgeInsets.all(16), child: Column(
                crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('Your private storage', style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text('${sizeText(used)} used of 5 GB'),
                  const SizedBox(height: 8),
                  LinearProgressIndicator(value: ratio, minHeight: 9),
                  const SizedBox(height: 4),
                  Text('${sizeText(quotaBytes - used)} available'),
                ],
              )),
            ),
            Expanded(child: docs.isEmpty
              ? const Center(child: Text('No files yet. Tap Upload to add your first file.'))
              : ListView.builder(itemCount: docs.length, itemBuilder: (context, index) {
                  final data = docs[index].data();
                  final name = data['name'] as String? ?? 'Unnamed file';
                  final size = ((data['size'] ?? 0) as num).toInt();
                  return ListTile(
                    leading: const Icon(Icons.insert_drive_file_outlined),
                    title: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis),
                    subtitle: Text(sizeText(size)),
                    trailing: IconButton(icon: const Icon(Icons.delete_outline),
                      onPressed: () => deleteFile(context, docs[index].id, data['storagePath'] as String? ?? '')),
                  );
                })),
          ]);
        },
      ),
    );
  }
}

Future<void> uploadFile(BuildContext context) async {
  final user = FirebaseAuth.instance.currentUser!;
  final picked = await FilePicker.platform.pickFiles(withData: true);
  if (picked == null || picked.files.isEmpty) return;
  final file = picked.files.single;
  final bytes = file.bytes;
  if (bytes == null) {
    showMessage(context, 'Could not read this file. Please try another file.');
    return;
  }
  if (bytes.length > maxFileBytes) {
    showMessage(context, 'Starter limit: each file must be 100 MB or smaller.');
    return;
  }

  final meta = FirebaseFirestore.instance.collection('users').doc(user.uid).collection('files');
  final existing = await meta.get();
  final used = existing.docs.fold<int>(0, (sum, d) => sum + ((d.data()['size'] ?? 0) as num).toInt());
  if (used + bytes.length > quotaBytes) {
    showMessage(context, 'Your 5 GB storage limit would be exceeded.');
    return;
  }

  final id = DateTime.now().microsecondsSinceEpoch.toString();
  final path = 'users/${user.uid}/$id-${file.name}';
  try {
    final ref = FirebaseStorage.instance.ref(path);
    await ref.putData(bytes, SettableMetadata(contentType: file.mimeType));
    await meta.doc(id).set({
      'name': file.name,
      'size': bytes.length,
      'storagePath': path,
      'createdAt': FieldValue.serverTimestamp(),
      'contentType': file.mimeType ?? 'application/octet-stream',
    });
    if (context.mounted) showMessage(context, 'Upload complete.');
  } on FirebaseException catch (e) {
    if (context.mounted) showMessage(context, 'Upload failed: ${e.message ?? e.code}');
  }
}

Future<void> deleteFile(BuildContext context, String id, String path) async {
  final user = FirebaseAuth.instance.currentUser!;
  try {
    if (path.isNotEmpty) await FirebaseStorage.instance.ref(path).delete();
    await FirebaseFirestore.instance.collection('users').doc(user.uid).collection('files').doc(id).delete();
    if (context.mounted) showMessage(context, 'File deleted.');
  } on FirebaseException catch (e) {
    if (context.mounted) showMessage(context, 'Delete failed: ${e.message ?? e.code}');
  }
}

void showMessage(BuildContext context, String message) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
}
